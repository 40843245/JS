function say( title,message ){
    console.log(title + ":" + message);
}

say("Email","Hello World"); // Email:Hello World