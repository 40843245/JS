function say( message ){
    console.log(message);
}

say("Hello World"); // Hello World