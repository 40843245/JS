function say( { message } ){
    console.log(message);
}

let object1 = {
    message:"Hello World"
};
say(object1); // Hello World