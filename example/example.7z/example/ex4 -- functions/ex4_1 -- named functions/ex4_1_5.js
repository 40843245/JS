function say( { title , message } ){
    console.log(title +":"+message);
}

let object1 = {
    title: "Email",
    message:"Hello World"
};
say(object1); // Email:Hello World