function say( { title , message } ){
    console.log(title +":"+message);
}

let object1 = {
    message:"Hello World",
    title: "Email"
};
say(object1); // Email:Hello World