function say(){
    console.log("Hello World");
}

say(); // Hello World