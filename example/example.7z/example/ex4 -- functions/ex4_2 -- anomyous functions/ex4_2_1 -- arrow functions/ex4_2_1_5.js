let hello = () => {
    document.getElementById("demo").innerHTML += this;
}
  
// The window object calls the function:
window.addEventListener("load", hello);

document.getElementById("btn").addEventListener("click", hello);