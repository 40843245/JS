# NOTICE
> [!NOTE]
> The arrow functions work only if there are one statement.