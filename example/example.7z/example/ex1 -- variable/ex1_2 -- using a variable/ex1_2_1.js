// How to create variables
var x;
let y;

// How to use variables
x = 5;
y = 6;
let z = x + y;