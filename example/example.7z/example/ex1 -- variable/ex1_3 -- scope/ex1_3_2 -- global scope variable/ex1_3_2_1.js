{
    var x = 2;
}
// x CAN be used here