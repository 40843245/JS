{
    let x = 2;
}
// x can NOT be used here