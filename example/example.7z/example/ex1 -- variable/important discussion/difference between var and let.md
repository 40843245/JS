# Difference between var and let
The main difference between variable that is defined with `var` and `let` are listed as follows.

+ Redeclaration

In strict mode, a variable that is declared with `let` keyword can not be redefined.

While a variable that is declared with `var` can. 

For example, it will not raise errors.

```
'use strict';
function main(){
    var x;
    var x;
}

main();
```

While the following code snippets will throw errors.

```
'use strict';
function main(){
    let x;
    let x; // <-- can not redeclared with a variable that is declared with `let` keyword.
}

main();
```

+ Scope of object property

The scope of a variable that is declared with `let` is in the block. In other word, it can be used in the block. 

Behaves as scope a variable in C.

While a variable that is declared with `var` is a globally scoped. 

That is, you can use it anywhere before/after the variable is declared with `var`. 

It belongs to `windows` object before/after the variable is declared with `var` in web browser.

> [!TIP]
> You may wonder why you can use it anywhere before/after the variable is declared with `var`.
>
> Because of there is a `hoisting` feature in variable that is declare with `var`.
>
> See next point for more details.

See the following example.

```
var foo = "Foo"; // globally scoped
let bar = "Bar"; // globally scoped but not part of the global object

console.log(window.foo); // Foo
console.log(window.bar); // undefined
```

+ Hoisting
Variables that is declared with `var` keyword are [hoisted and _initialized_](https://dev.to/godcrampy/the-secret-of-hoisting-in-javascript-egi) 

which means they are accessible in their enclosing scope even before they are declared.

However their value is `undefined` before the declaration statement is reached.

Variables that is declared with `let` keyword are [hoisted and _initialized_](https://dev.to/godcrampy/the-secret-of-hoisting-in-javascript-egi), 

so accessing variable that is declared with `let` before declaring it (and for those variable that is NOT declared yet) will throw error. 

See following examples.

```
function checkHoisting() {
  console.log(foo); // undefined
  var foo = "Foo";
  console.log(foo); // Foo
}

checkHoisting();
```

```
function checkHoisting() {
  console.log(foo); // <-- throw ReferenceError
  let foo = "Foo";
  console.log(foo); // Foo
}

checkHoisting();
```

+ Scoping rules
Variables declared by `var` keyword are scoped to the immediate function body (hence the function scope).

While `let` variables are scoped to the immediate _enclosing_ block denoted by `{}` (hence the block scope).

The reason why the strange phenomenon -- Variables declared by `var` keyword are scoped to the immediate function body (hence the function scope), occurs can be explained with the second point (`Scope of object property`) and previous point (`Hoisting`).

See the following examples.

```
function run() {
  var foo = "Foo";
  let bar = "Bar";

  console.log(foo, bar); // Foo Bar

  {
    var moo = "Mooo"
    let baz = "Bazz";
    console.log(moo, baz); // Mooo Bazz
  }

  console.log(moo); // Mooo
  console.log(baz); // <-- throw ReferenceError
}

run();
```

```
var funcs = [];
// let's create 3 functions
for (var i = 0; i < 3; i++) {
  // and store them in funcs
  funcs[i] = function() {
    // each should log its value.
    console.log("My value: " + i);
  };
}
for (var j = 0; j < 3; j++) {
  // and now let's run each one to see
  funcs[j]();
}
```

## reference
+ `ThinkingStiff`'s answer and `Gurpreet Singh`'s answer in this article -- [`Difference between var and let in JS?`](https://stackoverflow.com/questions/762011/what-is-the-difference-between-let-and-var) provides a detailed explanation of use of let and var.

+ In addition, this article -- [`Variables in JS (w3school)`] discuss about use case of `const`,`let`, and `var` in code writing.
