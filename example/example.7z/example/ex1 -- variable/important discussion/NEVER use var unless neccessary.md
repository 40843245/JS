# NEVER use var unless neccessary
I recommend NEVER use var unless neccessary for following reasons.

+ `var` is hairy. 

See the following example, and link of first point in reference section. 

```
var funcs = [];
// let's create 3 functions
for (var i = 0; i < 3; i++) {
  // and store them in funcs
  funcs[i] = function() {
    // each should log its value.
    console.log("My value: " + i);
  };
}
for (var j = 0; j < 3; j++) {
  // and now let's run each one to see
  funcs[j]();
}
```

+ `var` does NOT support for newer version of web browser.

See link of second point in reference section. 

## reference
+ `ThinkingStiff`'s answer and `Gurpreet Singh`'s answer in this article -- [`Difference between var and let in JS?`](https://stackoverflow.com/questions/762011/what-is-the-difference-between-let-and-var) provides a detailed explanation of use of let and var.

+ In addition, this article -- [`Variables in JS (w3school)`] discuss about use case of `const`,`let`, and `var` in code writing.