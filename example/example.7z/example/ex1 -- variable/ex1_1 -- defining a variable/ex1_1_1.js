const PI = 3.14159; // variable with `const` keyword can not be reassigned. Otherwise, it will throw error. 
let radius = 3;
var degree = 180;

console.log(PI);
console.log(radius);
console.log(degree);
