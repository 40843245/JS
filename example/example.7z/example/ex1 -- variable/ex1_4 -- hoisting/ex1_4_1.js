var x; // Declare x
x = 5; // Assign 5 to x