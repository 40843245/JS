/// The technique is called hoisting.

x = 5; // Assign 5 to x
var x; // Declare x