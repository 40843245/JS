function a() {
    console.log(1);
}
a = (function() {
    const origin = a;
    return function() {
      debugger;
      origin();
    }
})();
