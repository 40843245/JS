# Equivalent 
`ex8_1_1.js` and `ex8_1_2.js` are equivalent.