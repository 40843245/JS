function a() {
    console.log(1);
}
  
debug(a); // enable debugger when `a` function is executed.
// undebug(a); // disable debugger for `debug(a);`
