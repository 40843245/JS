# NOTICE
> [!NOTE]
> The logical operator in JS conforms to [`ECMAScript 2020`](https://www.w3schools.com/Js/js_2020.asp)