function printLogicalOperationsResult( x , y ){
    console.log("---------------------------------------------------");
    console.log("x" + ":" + x);
    console.log("y" + ":" + y);
    console.log(("x && y") + ":" + (x & y) );
    console.log(("x || y") + ":" + (x || y) );
    console.log(("!x") + ":" + (!x) );
    console.log("---------------------------------------------------");

}

let bool1 = true;
let bool2 = false;

printLogicalOperationsResult(bool1,bool1);
printLogicalOperationsResult(bool1,bool2);
printLogicalOperationsResult(bool2,bool1);
printLogicalOperationsResult(bool2,bool2);

/*
---------------------------------------------------
x:true
y:true
x && y:1
x || y:true
!x:false
---------------------------------------------------
---------------------------------------------------
x:true
y:false
x && y:0
x || y:true
!x:false
---------------------------------------------------
---------------------------------------------------
x:false
y:true
x && y:0
x || y:true
!x:true
---------------------------------------------------
---------------------------------------------------
x:false
y:false
x && y:0
x || y:false
!x:true
---------------------------------------------------
*/