function printOperationsResult( x , y  ){
    const NUMBER_TYPE = 'number';
    if(typeof x !== NUMBER_TYPE){
        throw new Error('Parameters x is NOT a number!');
    }

    if(typeof y !== NUMBER_TYPE){
        throw new Error('Parameters y is NOT a number!');
    }

    if( y == 0 ){
        throw new Error('y is zero');
    }

    console.log(x + y);
    console.log(x - y);
    console.log(x * y);
    console.log(x / y);
    console.log(x % y);
    console.log(x ** y);
}

printOperationsResult(2,3);

/*
5
-1
6
0.6666666666666666
2
8
*/