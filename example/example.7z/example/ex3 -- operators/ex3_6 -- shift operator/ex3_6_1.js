function printShiftOperationsResult( x , y ){
    console.log("---------------------------------------------------");
    console.log("x" + ":" + x);
    console.log("y" + ":" + y);
    console.log(("x << y") + ":" + (x << y) );
    console.log(("x >> y") + ":" + (x >> y) );
    console.log(("x >>= y") + ":" + (x >>= y) );
    console.log("---------------------------------------------------");

}

let number1 = 7;
let number2 = 3;

printShiftOperationsResult(number1,number2);

/*
---------------------------------------------------
x:7
y:3
x << y:56
x >> y:0
x >>= y:0
---------------------------------------------------
*/