let string1 = "Hello";
let string2 = "World";
let number1 = 2;

console.log(string1+string2);
console.log(string2+number1);
console.log(number1+string2);

/*
HelloWorld
World2
2World
*/