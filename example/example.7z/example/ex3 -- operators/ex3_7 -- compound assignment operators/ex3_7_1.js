function printCompoundAssignmentOperationResult(x){
    console.log("---------------------------------------------------");
    console.log("x" + ":" + x);
    x += 3; // equivalent to `x = x + 3`
    console.log("x" + ":" + x);
    x -= 1; // equivalent to `x = x - 1`
    console.log("x" + ":" + x);
    x *= 2; // equivalent to `x = x * 2`
    console.log("x" + ":" + x);
    x /= -0.5; // equivalent to `x = x / -0.5`
    console.log("x" + ":" + x);
    x **= 2; // equivalent to `x = x ** 2`
    console.log("x" + ":" + x);
    x %= 2; // equivalent to `x = x % 2`
    console.log("---------------------------------------------------");
}

let number1 = 2;

printCompoundAssignmentOperationResult(number1);

/*
---------------------------------------------------
x:2
x:5
x:4
x:8
x:-16
x:256
x:0
---------------------------------------------------
*/