function printCompoundAssignmentOperationResult(x,y){
    let z = x;
    console.log("---------------------------------------------------");
    console.log("x" + ":" + x);
    console.log("x" + ":" + y);
    console.log("z" + ":" + z);

    z = x;
    z ||= y; // equivalent to `z = z || y`
    console.log("z" + ":" + z);
    
    z = x;
    z &&= y; // equivalent to `z = z && y`
    console.log("z" + ":" + z);
    
    z = x;
    z ??= y; // equivalent to `z = y ?? ( z = y )`
    console.log("z" + ":" + z);
    console.log("---------------------------------------------------");
}

let bool1 = true;
let bool2 = false;

printCompoundAssignmentOperationResult(bool1,bool1);
printCompoundAssignmentOperationResult(bool1,bool2);
printCompoundAssignmentOperationResult(bool2,bool1);
printCompoundAssignmentOperationResult(bool2,bool2);

/*
---------------------------------------------------
x:true
x:true
z:true
z:true
z:true
z:true
---------------------------------------------------
---------------------------------------------------
x:true
x:false
z:true
z:true
z:false
z:true
---------------------------------------------------
---------------------------------------------------
x:false
x:true
z:false
z:true
z:false
z:false
---------------------------------------------------
---------------------------------------------------
x:false
x:false
z:false
z:false
z:false
z:false
---------------------------------------------------
*/