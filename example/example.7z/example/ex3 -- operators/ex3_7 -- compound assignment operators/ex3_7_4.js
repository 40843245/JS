function printCompoundAssignmentOperationResult(x){
    const TWO = 2;
    let z = x;
    console.log("---------------------------------------------------");
    console.log("x" + ":" + x);
    console.log("z" + ":" + z);

    z = x;
    z >>= TWO; // equivalent to `z = z >> 2`
    console.log("z" + ":" + z);
    
    z = x;
    z <<= TWO; // equivalent to `z = z << 15`
    console.log("z" + ":" + z);
    
    z = x;
    z >>>= TWO; // equivalent to `z = z >>> 2`
    console.log("z" + ":" + z);
    console.log("---------------------------------------------------");
}

let number1 = 0b1001;

printCompoundAssignmentOperationResult(number1);

/*
---------------------------------------------------
x:9
z:9
z:2
z:36
z:2
---------------------------------------------------
*/