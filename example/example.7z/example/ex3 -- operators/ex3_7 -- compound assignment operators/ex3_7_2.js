function printCompoundAssignmentOperationResult(x){
    const FIVETEEN = 15;
    let z = x;
    console.log("---------------------------------------------------");
    console.log("x" + ":" + x);
    console.log("z" + ":" + z);

    z = x;
    z &= FIVETEEN; // equivalent to `z = z & 15`
    console.log("z" + ":" + z);
    
    z = x;
    z |= FIVETEEN; // equivalent to `z = z | 15`
    console.log("z" + ":" + z);
    
    z = x;
    z ^= FIVETEEN; // equivalent to `z = z ^ 2`
    console.log("z" + ":" + z);
    console.log("---------------------------------------------------");
}

let number1 = 0b1001;

printCompoundAssignmentOperationResult(number1);

/*
---------------------------------------------------
x:9
z:9
z:9
z:15
z:6
---------------------------------------------------
*/