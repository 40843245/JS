function boolToString(x){
    return x.toString();
}

function printEqualityOperationResult(x,y){
    console.log("---------------------------------------------------");
    console.log("x" + ":" + x);
    console.log("y" + ":" + y);

    console.log("x==y" + ":" +boolToString(x==y));
    console.log("x!=y" + ":" + boolToString(x!=y));
    console.log("x===y" + ":" + boolToString(x===y));
    console.log("x!==y" + ":" + boolToString(x!==y));
    console.log("Object.is(x,y)" + ":" + boolToString(Object.is(x,y)));
    console.log("!Object.is(x,y)" + ":" + boolToString(!Object.is(x,y)));
    console.log("---------------------------------------------------");
}

let number1 = 2;
let number2 = 2;
let number3 = number2;
let number4 = 3;

printEqualityOperationResult(number1,number1);
printEqualityOperationResult(number1,number2);
printEqualityOperationResult(number1,number3);
printEqualityOperationResult(number1,number4);
printEqualityOperationResult(number2,number2);
printEqualityOperationResult(number2,number3);
printEqualityOperationResult(number2,number4);
printEqualityOperationResult(number3,number3);
printEqualityOperationResult(number3,number4);
printEqualityOperationResult(number4,number4);

/*
---------------------------------------------------
x:2
y:2
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:2
y:2
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:2
y:2
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:2
y:3
x==y:false
x!=y:true
x===y:false
x!==y:true
Object.is(x,y):false
!Object.is(x,y):true
---------------------------------------------------
---------------------------------------------------
x:2
y:2
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:2
y:2
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:2
y:3
x==y:false
x!=y:true
x===y:false
x!==y:true
Object.is(x,y):false
!Object.is(x,y):true
---------------------------------------------------
---------------------------------------------------
x:2
y:2
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:2
y:3
x==y:false
x!=y:true
x===y:false
x!==y:true
Object.is(x,y):false
!Object.is(x,y):true
---------------------------------------------------
---------------------------------------------------
x:3
y:3
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
*/