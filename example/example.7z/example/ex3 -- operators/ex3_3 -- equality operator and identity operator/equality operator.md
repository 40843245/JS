# equality operator
`==` is equality operator. 

In JS, equality comparison has different meaning in different contexts.

+ For primitive type, 

it compares its content.

It returns true iff they have same contents. Otherwise, returns false.

See `ex3_3_1.js` and `ex3_3_2.js`.

+ For non-primitive type,

it compares its reference using `Object.is` static method.

It returns true iff they point to same reference. Otherwise, return false.

See `ex3_3_3.js`.

> [!TIP]
> `!=` is opposite of `==`