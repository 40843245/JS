# Object.is static method
See `identity operator.md`.