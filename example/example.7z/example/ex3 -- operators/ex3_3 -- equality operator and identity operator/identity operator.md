# identity operator
`===` is identity operator. 

In JS, identity comparison compares two objects if they point to same reference through `Object.is` static method.

> [!TIP]
> `===` calls `Object.is` static method.

+ For primitive type, 

    - for `string`, due to `string literal`, if two strings has same content, it must always points same reference. 

    See `ex3_3_1.js`.

    > [!TIP]
    > String literal is a literal for string value in source code.
    > 
    > Image a set for literal, a string value is placed in a set, a string value is unique.
    > 
    > In Java, `"a"` is a string literal in an expression `String x = "a";`, if two strings has same content, it must always points same reference. (if you familar with Java, you might have heard `string literal`) 
    > 
    > For more explanation, see [`String literal`](https://en.wikipedia.org/wiki/String_literal)

    - for `number`, due to `number literal`, if two numbers has same content, it must always points same reference. 

    > [!TIP]
    > The concept of `number literal` and `string literal` is same.

    See `ex3_3_2.js`.

+ For non-primitive type,

it also compares its reference using `Object.is` static method.

It returns true iff they point to same reference. Otherwise, return false.

See `ex3_3_3.js`.

> [!TIP]
> `===` is opposite of `!==`

> [!TIP]
> `Object.is` is opposite of `!Object.is`
