function boolToString(x){
    return x.toString();
}

function printEqualityOperationResult(x,y){
    console.log("---------------------------------------------------");
    console.log("x" + ":" + x);
    console.log("y" + ":" + y);

    console.log("x==y" + ":" +boolToString(x==y));
    console.log("x!=y" + ":" + boolToString(x!=y));
    console.log("x===y" + ":" + boolToString(x===y));
    console.log("x!==y" + ":" + boolToString(x!==y));
    console.log("Object.is(x,y)" + ":" + boolToString(Object.is(x,y)));
    console.log("!Object.is(x,y)" + ":" + boolToString(!Object.is(x,y)));
    console.log("---------------------------------------------------");
}

let string1 = "Hello";
let string2 = "Hello";
let string3 = string2;
let string4 = "World";


printEqualityOperationResult(string1,string1);
printEqualityOperationResult(string1,string2);
printEqualityOperationResult(string1,string3);
printEqualityOperationResult(string1,string4);
printEqualityOperationResult(string2,string2);
printEqualityOperationResult(string2,string3);
printEqualityOperationResult(string2,string4);
printEqualityOperationResult(string3,string3);
printEqualityOperationResult(string4,string4);


/*
---------------------------------------------------
x:Hello
y:Hello
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:Hello
y:Hello
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:Hello
y:Hello
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:Hello
y:World
x==y:false
x!=y:true
x===y:false
x!==y:true
Object.is(x,y):false
!Object.is(x,y):true
---------------------------------------------------
---------------------------------------------------
x:Hello
y:Hello
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:Hello
y:Hello
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:Hello
y:World
x==y:false
x!=y:true
x===y:false
x!==y:true
Object.is(x,y):false
!Object.is(x,y):true
---------------------------------------------------
---------------------------------------------------
x:Hello
y:Hello
x==y:true
x!=y:false
x===y:true
*/