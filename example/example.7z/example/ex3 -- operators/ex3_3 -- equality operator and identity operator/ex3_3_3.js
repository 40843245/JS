function boolToString(x){
    return x.toString();
}

function printEqualityOperationResult(x,y){
    console.log("---------------------------------------------------");
    console.log("x" + ":" + x);
    console.log("y" + ":" + y);

    console.log("x==y" + ":" +boolToString(x==y));
    console.log("x!=y" + ":" + boolToString(x!=y));
    console.log("x===y" + ":" + boolToString(x===y));
    console.log("x!==y" + ":" + boolToString(x!==y));
    console.log("Object.is(x,y)" + ":" + boolToString(Object.is(x,y)));
    console.log("!Object.is(x,y)" + ":" + boolToString(!Object.is(x,y)));
    console.log("---------------------------------------------------");
}

let object1 = {
    name: "Jay",
    age:20,
};

let object2 = {
    name: "Jay",
    age:20,
};

let object3 = object2;

let object4 = {
    name: "Jay",
    age:24,
};


printEqualityOperationResult(object1,object1);
printEqualityOperationResult(object1,object2);
printEqualityOperationResult(object1,object3);
printEqualityOperationResult(object1,object4);
printEqualityOperationResult(object2,object2);
printEqualityOperationResult(object2,object3);
printEqualityOperationResult(object2,object4);
printEqualityOperationResult(object3,object3);
printEqualityOperationResult(object3,object4);
printEqualityOperationResult(object4,object4);

/*
---------------------------------------------------
x:[object Object]
y:[object Object]
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:[object Object]
y:[object Object]
x==y:false
x!=y:true
x===y:false
x!==y:true
Object.is(x,y):false
!Object.is(x,y):true
---------------------------------------------------
---------------------------------------------------
x:[object Object]
y:[object Object]
x==y:false
x!=y:true
x===y:false
x!==y:true
Object.is(x,y):false
!Object.is(x,y):true
---------------------------------------------------
---------------------------------------------------
x:[object Object]
y:[object Object]
x==y:false
x!=y:true
x===y:false
x!==y:true
Object.is(x,y):false
!Object.is(x,y):true
---------------------------------------------------
---------------------------------------------------
x:[object Object]
y:[object Object]
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:[object Object]
y:[object Object]
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:[object Object]
y:[object Object]
x==y:false
x!=y:true
x===y:false
x!==y:true
Object.is(x,y):false
!Object.is(x,y):true
---------------------------------------------------
---------------------------------------------------
x:[object Object]
y:[object Object]
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
---------------------------------------------------
x:[object Object]
y:[object Object]
x==y:false
x!=y:true
x===y:false
x!==y:true
Object.is(x,y):false
!Object.is(x,y):true
---------------------------------------------------
---------------------------------------------------
x:[object Object]
y:[object Object]
x==y:true
x!=y:false
x===y:true
x!==y:false
Object.is(x,y):true
!Object.is(x,y):false
---------------------------------------------------
*/