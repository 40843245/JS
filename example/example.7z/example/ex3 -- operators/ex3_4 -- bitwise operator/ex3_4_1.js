function printBitwiseOperationsResult( x ){
    const NUMBER_TYPE = 'number';
    if(typeof x !== NUMBER_TYPE){
        throw new Error('Parameters x is NOT a number!');
    }
    
    const FIVETEEN = 15;
    console.log("---------------------------------------------------");
    console.log("x" + ":" + x);
    console.log(("x & "+ FIVETEEN ) + ":" + (x & FIVETEEN) );
    console.log(("x | " + FIVETEEN ) + ":" + (x | FIVETEEN) );
    console.log(("x ^ "+ FIVETEEN ) + ":" + (x ^ FIVETEEN) );
    console.log(("~x") + ":" + (~x) );
    console.log("---------------------------------------------------");

}

let number1 = 0b1001
printBitwiseOperationsResult(number1);

/*
---------------------------------------------------
x:9
x & 15:9
x | 15:15
x ^ 15:6
~x:-10
---------------------------------------------------
*/