let object1 = {
    name: "Jay",
    age: 24
};
console.log(typeof object1); // object