let array2 = [{
    name: "Jay",
    age: 24
}];
console.log(typeof array2); // object