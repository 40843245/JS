let array1 = Array(1,2,3);
console.log(typeof array1); // object