var rex = {
    name:'rex',
    writeName:function(){
        return 'Name is ' + this.name;
    },
};
console.log("----------------------------------------");

// Object,values(rex) will return a list-like container containing all values in rex.
console.log(Object.values(rex));


console.log("----------------------------------------");

// Object,keys(rex) will return a list-like container containing all keys in rex.
// NOTE that all keys in JS are string type, even if adding a new key with a number. 
// For example, adding a new key `2`, will adding a new key `"2"`
console.log(Object.keys(rex));

console.log("----------------------------------------");

// return the value with key `name`. 
console.log(rex.name); 

console.log("----------------------------------------");

// return the value with key `writeName`. 
console.log(rex.writeName); //

console.log("----------------------------------------");

// return the value with key `age`.
console.log(rex.age); // prints `undefined` since it has no key `age`.

console.log("----------------------------------------");

// Since the value of key `writeName` is a function,  
// so rex.writeName` is a function, 
// thus, `rex.writeName()` will invoke the function 
rex.writeName(); // prints `Name is rex`.

console.log("----------------------------------------");

// assign 18 into the value of key `age` 
rex.age=18; // since the key `age` does NOT exist, thus it will add key `age`.

console.log(rex.age); // prints `18`
console.log("----------------------------------------");

// assign 18 into the value of key `age`.
rex.age=20; // since the key `age` does exists, thus it will NOT add key `age`.
console.log(rex.age); // prints `20`.

console.log("----------------------------------------");

// Since `'a'+'g'+'e'` is evaluates to `age`, 
// rex['a'+'g'+'e'] is equal to rex['age'];
console.log(rex['a'+'g'+'e']); // prints `20`

console.log("----------------------------------------");

// Since `1+1` is evaluated to `2`,
// rex[1+1] is equal to rex[2];
// Note that since in JS, it always handles the index (inside `[]`) with `string` type),
// rex[2] is equal to rex["2"];

rex[1+1]='abc' // add key `"2"` then assign 'abc' into key `"2"``. 

console.log("----------------------------------------");

// NOTE that all keys in JS are string type, even if adding a new key with a number.
console.log(Object.keys(rex)); // so prints ["name","writeName","age","2"]

console.log("----------------------------------------");

// Note that since in JS, it always handles the index (inside `[]`) with `string` type),
// rex[2] is equal to rex["2"];
console.log(rex[0+2]); // prints `'abc'`

console.log("----------------------------------------");

console.log(rex[rex.writeName]); // prints `undefined`

console.log("----------------------------------------");

rex['writeName'](); // invoke rex.writeName();

console.log("----------------------------------------");

let x = delete rex[2]; // return true when it deletes the key successfully.
console.log(x);

console.log("----------------------------------------");

console.log(Object.keys(rex)); // prints ["name","writeName","age"]

console.log("----------------------------------------");

console.log(rex[2]); // prints `undefined`

console.log("----------------------------------------");

/*
----------------------------------------
[ 'rex', [Function: writeName] ]
----------------------------------------
[ 'name', 'writeName' ]
----------------------------------------
rex
----------------------------------------
[Function: writeName]
----------------------------------------
undefined
----------------------------------------
----------------------------------------
18
----------------------------------------
20
----------------------------------------
20
----------------------------------------
----------------------------------------
[ '2', 'name', 'writeName', 'age' ]
----------------------------------------
abc
----------------------------------------
undefined
----------------------------------------
----------------------------------------
true
----------------------------------------
[ 'name', 'writeName', 'age' ]
----------------------------------------
undefined
----------------------------------------
*/