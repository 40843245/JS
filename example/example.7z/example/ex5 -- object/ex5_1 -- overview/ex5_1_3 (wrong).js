var rex = {
    name:'rex',
    writeName:function(){
        return 'Name is ' + this.name;
    },
};

console.log("------------------------------------------");

console.log(rex[writeName]); // <-- throw ReferenceError

console.log("------------------------------------------");