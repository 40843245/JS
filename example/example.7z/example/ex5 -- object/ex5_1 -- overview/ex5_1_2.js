var rex = {
    name:'rex',
    writeName:function(){
        return 'Name is ' + this.name;
    },
};

console.log("------------------------------------------");

console.log(rex.writeName);

console.log("------------------------------------------");

console.log(rex[rex.writeName]);

console.log("------------------------------------------");

/*
------------------------------------------
[Function: writeName]
------------------------------------------
undefined
------------------------------------------
*/