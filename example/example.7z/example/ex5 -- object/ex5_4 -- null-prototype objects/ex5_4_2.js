const normalObj = {}; // create a normal object
const nullProtoObj = Object.create(null); // create an object with "null" prototype

console.log(`normalObj is: ${normalObj}`); // shows "normalObj is: [object Object]"
console.log(`nullProtoObj is: ${nullProtoObj}`); // throws error: Cannot convert object to primitive value

alert(normalObj); // shows [object Object]
alert(nullProtoObj); // throws error: Cannot convert object to primitive value

console.log(normalObj.valueOf()); // shows {}
console.log(nullProtoObj.valueOf()); // throws error: nullProtoObj.valueOf is not a function

console.log(normalObj.hasOwnProperty("p")); // shows "true"
console.log(nullProtoObj.hasOwnProperty("p")); // throws error: nullProtoObj.hasOwnProperty is not a function

console.log(normalObj.constructor); // shows "Object() { [native code] }"
console.log(nullProtoObj.constructor); // shows "undefined"

nullProtoObj.toString = Object.prototype.toString; // since new object lacks toString, add the original generic one back

console.log(nullProtoObj.toString()); // shows "[object Object]"
console.log(`nullProtoObj is: ${nullProtoObj}`); // shows "nullProtoObj is: [object Object]"
