const obj = Object.create(null);
const obj2 = { __proto__: null };

console.log(obj);
console.log(obj2);

/*
[Object: null prototype] {}
[Object: null prototype] {}
*/