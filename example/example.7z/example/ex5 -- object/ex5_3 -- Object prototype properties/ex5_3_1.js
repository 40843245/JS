const obj = {
    foo: 1,
    // You should not define such a method on your own object,
    // but you may not be able to prevent it from happening if
    // you are receiving the object from external input
    propertyIsEnumerable() {
      return false;
    },
  };
  
console.log(obj.propertyIsEnumerable("foo")); // false; unexpected result
console.log(Object.prototype.propertyIsEnumerable.call(obj, "foo")); // true; expected result
  