const fruits = ["Banana", "Orange", "Apple", "Mango"];
const moreFruits = ["Kiwi"];

console.log(fruits[0]);
console.log(fruits.at(0));
// console.log(fruits[-1]); // NOT find the last index. 
console.log(fruits.at(-1)); // find the last index. 

console.log(fruits.length);
console.log(fruits.toString());
console.log(fruits.join('-'));
console.log(fruits.concat(moreFruits));
console.log(fruits.concat("Blueberry"));

let lastOldElement = fruits.pop();
console.log(lastOldElement);

let newLength = fruits.push("Grape");
console.log(newLength);

let firstOldElement = fruits.shift();
console.log(firstOldElement);

newLength = fruits.unshift("Lemon");
console.log(newLength);

fruits[fruits.length] = "Passionate";

// remove zero index of fruits, 
// returns true iff delete successfully. 
// But not free up memory in Array data structure, leaving undefined at zero index. 
let deleteSuccessfully = delete fruits[0]; 
console.log(deleteSuccessfully);

console.log(fruits.splice(2, 0, "Lemon", "Kiwi"));
console.log(fruits.splice(2, 2, "Grape", "Blueberry"));

fruits.splice(0, 1); // You can use splice() to remove elements without leaving "holes" in the array.

console.log(fruits.copyWithin(2, 0)); // Copy to index 2, all elements from index 0.

console.log(fruits.copyWithin(2, 0, 2)); // Copy to index 2, the elements from index 0 to 2.

console.log(fruits.indexOf("Apple"));

console.log(fruits.lastIndexOf("Apple"));

console.log(fruits.includes("Mango"));

console.log(fruits.keys());
console.log(fruits.values());
console.log(fruits.entries());

console.log(fruits.with(2, "Mango"));

// sort the Array with alphabet order.
const unsortedFruit = structuredClone(fruits);
console.log(unsortedFruit.toSorted());
console.log(unsortedFruit);
unsortedFruit.sort();
console.log(unsortedFruit); 

// reverse the Array.
const unreversedFruit = structuredClone(fruits);
console.log(unreversedFruit.toReversed());
console.log(unreversedFruit);
unreversedFruit.reverse();
console.log(unreversedFruit);

const myArr = [[1,2],[3,4],[5,6]];
let newArr = myArr.flat()
console.log(newArr);

let newArr2 = newArr.flatMap(x => [x, x * 10]);
console.log(newArr2);

// Slice out a part of an array starting from array element 1 ("Orange").
const citrus = fruits.slice(1); 

const months = ["Jan", "Feb", "Mar", "Apr"];
// ES2023 added the Array toSpliced() method as a safe way to splice an array without altering the original array.
const spliced = months.toSpliced(0, 1);

const numbers1 = [4, 9, 16, 25, 36,49,64,81,100];
console.log(numbers1.find(greaterThan18));
console.log(numbers1.findIndex(greaterThan18));
console.log(numbers1.findLast(greaterThan18));

console.log(numbers1.filter(greaterThan18));

console.log(numbers1.every(greaterThan18));
console.log(numbers1.some(greaterThan18));

function greaterThan18(value, index, array) {
  return value > 18;
}

const scores = [40, 100, 1, 5, 25, 10];
console.log(myArrayMin(scores));
console.log(myArrayMax(scores));

function myArrayMin(arr) {
    return Math.min.apply(null, arr);
}

function myArrayMax(arr) {
    return Math.max.apply(null, arr);
}

const numbers2 = [45, 4, 9, 16, 25];
let txt = "";
numbers2.forEach(joinWithBr);

function joinWithBr(value, index, array) {
  txt += value + "<br>";
}
console.log(txt);

console.log(numbers2.map(double));
console.log(numbers2.flatMap(double));
function double(value, index, array){
    return value * 2;
}

const numbers3 = [4, 9, 16, 25, 36,49,64,81,100];
console.group(GROUP_NAME);
console.log(numbers3.reduce(sum));
console.groupEnd();

console.group(GROUP_NAME);
console.log(numbers3.reduce(sum,-2000)); // With initial value.
console.groupEnd();

console.group(GROUP_NAME);
console.log(numbers3.reduceRight(sum));
console.groupEnd();

console.group(GROUP_NAME);
console.log(numbers3.reduceRight(sum,-2000)); // With initial value.
console.groupEnd();

function sum(total, value, index, array) {
    const GROUP_NAME = 'group1';
    return total + value;
}

console.log(Array.from("ABCDEFG"));

const q1 = ["Jan", "Feb", "Mar"];
const q2 = ["Apr", "May", "Jun"];
const q3 = ["Jul", "Aug", "Sep"];
const q4 = ["Oct", "Nov", "May"];

console.log([...q1, ...q2, ...q3, ...q4]);
