const cars = ["Saab", "Volvo", "BMW"];
console.log(cars[0]);
cars[4] = "Saab";
console.log(cars[4]);