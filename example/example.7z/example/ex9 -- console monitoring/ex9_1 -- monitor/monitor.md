# monitor
## parameter
`monitor` function accepts an argument where first argument is a function except an anomynous function.

## difference between `monitor` function and `debug` function
`monitor` function behaves similar to `debug` function.

But `monitor` function can print function name and function parameter of passed first argument.

Since it can print function name, it can NOT pass an anomynous function as first argument.