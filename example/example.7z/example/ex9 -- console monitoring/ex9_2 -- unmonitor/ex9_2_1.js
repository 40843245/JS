function a() {
    console.log(1);
}
  
monitor(a); // enable monitor when `a` function is executed.
unmonitor(a); // disable monitor for `monitor(a);`