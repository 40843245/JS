# monitorEvents
## syntax
```
monitorEvents(element[, eventType])
```

## parameter
it accepts one or two argument.

+ Case 1: 
 
When only one argument is passed, 
 
it will monitor all events of the element (passed in first argument).
 
+ Case 2:

When two arguments are passed,

it will monitor the specific event (passed in second argument) of the element (passed in first argument). 