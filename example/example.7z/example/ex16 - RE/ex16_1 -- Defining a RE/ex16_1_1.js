const regex1 = /ab+c/g;
const regex2 = new RegExp("ab+c", "g");
