# RE in JS.md
## reference
See [`RE in JS`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Regular_expressions)