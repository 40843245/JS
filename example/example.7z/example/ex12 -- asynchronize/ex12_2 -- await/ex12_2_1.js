import promiseFn from "../promiseFn.js";

async function promiseAll() {
    const data = await Promise.all([promiseFn(1, 3000), promiseFn(2)]);
    console.log(data)
}
promiseAll(); // prints `["1, 成功", "2, 成功"]` when successfully run the code.