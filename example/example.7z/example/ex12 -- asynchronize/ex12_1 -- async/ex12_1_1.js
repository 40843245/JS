async function asyncFn() {
    return 'a';
}
console.log(asyncFn());