/**
 * 範例 Promise 函式
 * 
 * @param {數值：作為判斷非同步成功與否的條件} num 
 * @param {數值：非同步所執行的時間長度} [time=500] 
 * @returns {如果 num 為真則套用 resolve；失敗則套用 reject}
 */
function promiseFn(num, time = 500) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        num ? resolve(`${num}, 成功`) : reject('失敗');
      }, time);
    });
  }