# Does overloading exist in JS?
## answer
The answer is `NO`.

What a pity that there is no overloading in JS.

If one declare more functions with same name, when calling the function, there are several principles to decide which function will be called.

+ According to scope, which has similar concepts of access variable determined by scope,

    - the function that is declared in inner block scope will be invoked.
    - If there are more functions with same name declared in same scope, 
    
    the function which is latest declared will be invoked. 
    
    The phenomenon is usually said to 
    
    `The function which is latest declared overwrite all other functions with same name.`. 

The principle is applied to declaring more methods with same name in class.

## In C++, there are function overloading, but there are no in JS? How to do same functionality without function overloading?

Check the argument in function.

For example,

```
function CatStrings(p1, p2, p3)
{
  var s = p1;
  if(typeof p2 !== "undefined") {s += p2;}
  if(typeof p3 !== "undefined") {s += p3;}
  return s;
};

CatStrings("one");        // result = one
CatStrings("one",2);      // result = one2
CatStrings("one",2,true); // result = one2true
```

> [!NOTE]
> In above example, `CatStrings` requires at most three parameter.
> 
> If one passed two arguments, the thrid argument will be `undefined`.

## reference
See [`Function overloading in Javascript - Best practices [closed]`](https://stackoverflow.com/questions/456177/function-overloading-in-javascript-best-practices)