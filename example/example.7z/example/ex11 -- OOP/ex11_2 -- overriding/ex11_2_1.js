class Person{
    constructor(name){
        this.name = name;
    }
}

class Vehicle {
    buyer; 
    salesperson = new Person("Jay");
    
    constructor(name, produceYear) {
      this.name = name;
      this.produceYear = produceYear;
    }
    
    age() {
      const date = new Date();
      return date.getFullYear() - this.produceYear;
    }
}

class Car extends Vehicle{
    wheelCount = 4;
    // overriding a field.
    salesperson = new Person("Peter");
    
    // overriding a method.
    age(){
      return super.age() + 1;
    }
}

const myCar = new Car("Jason Tatum",2011);
console.log(myCar.name + " has " + wheelCount + " wheel(s).");