# reference
## code reference
From [`Encapsulation in JavaScript (GeeksForGeeks)`](https://www.geeksforgeeks.org/encapsulation-in-javascript/)