# getter
There are no getter, but you can declare a function that only returns a field to do what a getter should do.

> [!TIP]
> It is recommended that declare the method start with `get` and use Camel case.
>
> For example, `getName`.