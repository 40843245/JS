class Person{
    constructor(name){
        this.name = name;
    }
}

class Vehicle {
    #buyer; // private non-static field without initial value.
    #salesperson = new Person("Jay"); // private non-static field with initial value.

    constructor(name, produceYear) {
      this.name = name;
      this.produceYear = produceYear;
    }

    age() {
      const date = new Date();
      return date.getFullYear() - this.produceYear;
    }
}

const myVehicle = new Vehicle("Ford", 2014);
console.log("My vehicle is " + myVehicle.age() + " years old.");