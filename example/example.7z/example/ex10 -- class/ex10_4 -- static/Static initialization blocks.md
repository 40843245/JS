# Static initialization blocks
## reference
see [`Static initialization blocks`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Classes/Static_initialization_blocks)
