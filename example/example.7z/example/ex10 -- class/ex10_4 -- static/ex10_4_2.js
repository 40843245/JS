class Person{
    constructor(name){
        this.name = name;
    }
}

class Vehicle {
    #buyer;
    #salesperson = new Person("Jay");

    constructor(name, produceYear) {
      this.name = name;
      this.produceYear = produceYear;
    }

    age() {
      const date = new Date();
      return date.getFullYear() - this.produceYear;
    }

    static #isWhiteNoise(message){ // private static method
      if(typeof(message) !== "string"){
        return false;
      }
      return ((message == 'WhiteNoise' )? true : false); 
    }

    static makeNoise(message){ 
        console.log(message);
        console.log("Is " + message + " a white noise? " + Vehicle.#isWhiteNoise(message));
        console.log("Is " + message + " a white noise? " + this.#isWhiteNoise(message));
        console.log("Is " + message + " a white noise? " + Vehicle['#isWhiteNoise'](message));
    }
}

const myVehicle = new Vehicle("Ford", 2014);
console.log("My vehicle is " + myVehicle.age() + " years old.");
myVehicle.makeNoise("Wow!!!");