class Person{
    constructor(name){
        this.name = name;
    }
}

class Vehicle {
    #buyer;
    #salesperson = new Person("Jay");

    constructor(name, produceYear) {
      this.name = name;
      this.produceYear = produceYear;
    }

    age() {
      const date = new Date();
      return date.getFullYear() - this.produceYear;
    }

    static makeNoise(message){ // public static method
        console.log(message);
    }
}


const myVehicle = new Vehicle("Ford", 2014);
console.log("My vehicle is " + myVehicle.age() + " years old.");
myVehicle.makeNoise("Wow!!!");