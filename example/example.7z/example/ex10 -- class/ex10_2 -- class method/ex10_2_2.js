class Vehicle {
    constructor(name, produceYear) {
      this.name = name;
      this.produceYear = produceYear;
    }

    #age() { // private non-static method
      const date = new Date();
      return date.getFullYear() - this.produceYear;
    }
}

const myVehicle = new Car("Ford", 2014);
console.log("My vehicle is " + myVehicle.age() + " years old."); // error, can NOT refer an private method