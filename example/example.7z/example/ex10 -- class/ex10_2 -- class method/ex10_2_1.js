class Vehicle {
    constructor(name, produceYear) {
      this.name = name;
      this.produceYear = produceYear;
    }
    // NOTE that there is no `function` keyword
    // DO NOT type `function age()`
    age() { // public non-static method
      const date = new Date();
      return date.getFullYear() - this.produceYear;
    }
}

const myVehicle = new Car("Ford", 2014);
console.log("My vehicle is " + myVehicle.age() + " years old.");