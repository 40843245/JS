# private in JavaScript and TypeScript
## reference
This article [`What are the differences between the private keyword and private fields in TypeScript?`](https://stackoverflow.com/questions/59641564/what-are-the-differences-between-the-private-keyword-and-private-fields-in-types) gives a more detailed explanation.