# Private field '#xxx' must be declared in an enclosing class.md
## reference
See [`How to fix 'Private field must be declared in an enclosing class'`](https://stackoverflow.com/questions/70645236/how-to-fix-private-field-must-be-declared-in-an-enclosing-class)