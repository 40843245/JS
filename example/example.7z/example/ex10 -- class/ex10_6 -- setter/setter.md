# setter
There are no setter, but you can declare a function that only sets a field to do what a setter should do.

> [!TIP]
> It is recommended that declare the method start with `set` and use Camel case.
>
> For example, `setName`.