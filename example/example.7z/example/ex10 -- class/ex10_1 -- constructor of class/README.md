# NOTICE
> [!NOTE]
> If you do not define a constructor method, it will add an empty constructor method.