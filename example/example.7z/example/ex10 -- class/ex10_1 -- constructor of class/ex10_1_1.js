class Vehicle {
    constructor(name, produceYear) {
      this.name = name;
      this.produceYear = produceYear;
    }
}