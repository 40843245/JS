const obj1 = {};
const obj2 = {
    name:"Jay"
};

const obj3 = Object.assign(obj1,obj2);
