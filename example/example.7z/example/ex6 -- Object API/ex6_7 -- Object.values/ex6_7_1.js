const object1 = {
    a: 'somestring',
    b: 42,
    c: false,
  };
  
  console.log(Object.values(object1));
  // Expected output: Array ["somestring", 42, false]
  