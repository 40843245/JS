const object1 = {
    prop: 'exists',
  };
  
  console.log(Object.hasOwn(object1, 'prop'));
  // Expected output: true
  
  console.log(Object.hasOwn(object1, 'toString'));
  // Expected output: false
  
  console.log(Object.hasOwn(object1, 'undeclaredPropertyValue'));
  // Expected output: false
  