if (req.cookies['name']) {
    // 有新的就用新的
    cookieVal = req.cookies['name'];
  } else if (req.cookies['name-legacy']) {
    // 不然就用舊的
    cookieVal = req.cookies['name-legacy'];
  }