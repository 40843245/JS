# enable CORS
## Way 1
Add `Access-Control-Allow-Origin` flag in Request Header at back-end side.

For example,

```
Access-Control-Allow-Origin: *                   # 同意啦，哪次不同意
Access-Control-Allow-Origin: http://example.com  # 只允許 http://example.com
```