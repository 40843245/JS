import axios from "axios";

var uuid = '86bfd5d2-b7d3-4a55-93e6-ef6299ba4c1c'; // UUID of store
var path = `https://course-ec-api.hexschool.io/api/${uuid}/ec/shopping`; 

console.log(`path:${path}`);

var data = {
    product: "mRdI2EbpTVMguM0jbqvlP6h6b007ySFLYLxyqO0qTWtXASP0sJJ7JlrpO9avHqWt", // product ID
    quantity: 1
}

axios.post(path, data)
  .then(res => {
    console.log(res);
  })
  .catch(error => {
    console.log(error.response);
  });


  function addToCart() {
    axios.post(path, data)
    .then(res => {
      console.log(res.data);
      showText(res.data, 'POST');
    })
      .catch(error => {
      console.log(error.response);
      showText(error.response, 'POST 失敗');
    });
  }