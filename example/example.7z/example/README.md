# IDE
I use [`Programiz JavaScript Online Compiler`] to run JS code in example folder.