const groupName = 'groupName';

console.group(groupName);
console.groupEnd(); // close the current group;