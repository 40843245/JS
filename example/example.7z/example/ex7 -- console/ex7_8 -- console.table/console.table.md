# console.table
## intro
`console.table` prints the evaluated value on first agrument on the console, but with table-style.

It is useful when the evaluated value on first agrument is an object.