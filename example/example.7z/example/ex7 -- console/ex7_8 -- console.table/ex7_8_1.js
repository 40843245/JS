const table1 = [
    {
      "name": "Frozen yoghurt",
      "calories": 159,
      "fat": 6,
      "carbs": 24,
      "protein": 4
    },
    {
      "name": "Ice cream sandwich",
      "calories": 237,
      "fat": 9,
      "carbs": 37,
      "protein": 4.3
    },
    {
      "name": "Eclair",
      "calories": 262,
      "fat": 16,
      "carbs": 24,
      "protein": 6
    }
];

console.table(table1); // print the table1 on the console, but with table-style.


