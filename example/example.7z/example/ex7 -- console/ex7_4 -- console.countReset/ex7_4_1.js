const FLAG = "render"
console.count(FLAG); // increase 1 of counter named FLAG that will be printed.
console.countReset(FLAG); // reset the counter named FLAG to 0.
