# console.assert
## difference between `console.assert` and `console.log`
`console.assert` behaves similar to `console.log`, 

but prints the value of second argumenet (in `ex7_2_1.js`, it is `This is a falsy value`) 

iff the value of first argument is evaluated to falsy value. 