let falsyValue1 = false;
let falsyValue2 = null; // nil value
let falsyValue3 = undefined; // declared but not undefined
let falsyValue4 = 0;
let falsyValue5 = -0; 
let falsyValue6 = 0n; // 0 with BigInt type
let falsyValue7 = NaN; // Nan i.e. Not A Number.
let falsyValue8 = ""; // empty string


console.assert(falsyValue1,"This is a falsy value"); // prints `This is a falsy value`.
console.assert(falsyValue2,"This is a falsy value"); // prints `This is a falsy value`.
console.assert(falsyValue3,"This is a falsy value"); // prints `This is a falsy value`.
console.assert(falsyValue4,"This is a falsy value"); // prints `This is a falsy value`.
console.assert(falsyValue5,"This is a falsy value"); // prints `This is a falsy value`.
console.assert(falsyValue6,"This is a falsy value"); // prints `This is a falsy value`.
console.assert(falsyValue7,"This is a falsy value"); // prints `This is a falsy value`.
console.assert(falsyValue8,"This is a falsy value"); // prints `This is a falsy value`.
