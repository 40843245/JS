const groupName = 'groupName';

// customize the group by the evaluated value of `groupName`.
console.group(groupName);