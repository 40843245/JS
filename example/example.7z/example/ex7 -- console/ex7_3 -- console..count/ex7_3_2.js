for (let i = 0; i < 5; i++) {
    const integer1 = Math.ceil(Math.random() * 100);
    if (integer1 < 20) console.count('too high');
    if (integer1 > 20) console.count('too low');
}