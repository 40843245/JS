function count(arg) {
    console.count(arg);
}
count('foo');
count('bar');
count('bar');