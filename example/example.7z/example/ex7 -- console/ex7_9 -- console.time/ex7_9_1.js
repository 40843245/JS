console.time('Spent'); // start timer that named `Spent`.
alert('Hello World!');
console.timeLog('Spent'); // print current running time in timer that named `Spent`.
alert('Another Hello World!');
console.timeEnd('Spent'); // close timer that named `Spent`.