# console.groupCollapsed
## difference between `console.groupCollapsed` and `console.group` 
`console.groupCollapsed` behaves similar to `console.group`. 

But, in group with `console.group`, the output printed in console are NOT collapsed, are expanded.

While, in group with `console.groupCollapsed`, the output printed in console are collapsed, are NOT expanded. One has to expand it manually.