const groupName = 'groupName';

console.groupCollapsed(groupName);
console.groupEnd(); // close the current group;