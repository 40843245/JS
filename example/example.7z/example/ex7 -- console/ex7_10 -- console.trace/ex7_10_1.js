function a() {
    console.trace();
}

function b() {
    a();
}

function c() {
    b();
}

b()
c()