# console.trace
## intro
`console.trace` prints the stack trace on the console.
